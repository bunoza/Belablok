package com.bunoza.belablok;

public interface NameClickListener {
    void onNameClick(int position);
}
